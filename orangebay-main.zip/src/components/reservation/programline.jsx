import React from 'react'

export default function Programline() {
  return (
    <div>
      <img src="program.png" width={416} height={596} alt="" />
    </div>
  )
}
