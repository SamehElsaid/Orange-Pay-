import React from 'react'

export default function IncludedExcluded() {
  return (
    <div className='container mt-4'>
        <div className='row'>
<div className='col-md-6'>
    <img src="included.png" alt="" />
</div>
<div className='col-md-6'>
    <img src="excluded.png" alt="" />
</div>

        </div>
      
    </div>
  )
}
